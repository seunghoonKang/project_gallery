export { default as Main } from './main';
export { default as Home } from './home';
export { default as Write } from './write';