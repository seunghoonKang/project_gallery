import { Main } from './page/index.js'
// ... render 부분
<div>
    <Main />
</div>
