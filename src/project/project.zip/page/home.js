import React, { Component } from 'react';

class home extends Component {
  constructor(props) {
    super(props)
  }

  render() {

    return (
        <div>
          <div>
            <h2> This is Home </h2>
          </div>
        </div>
    );
  }
}

export default home;

