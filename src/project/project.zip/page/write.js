import React, { Component } from 'react';

class write extends Component {
  constructor(props) {
    super(props)
  }

  render() {

    return (
        <div>
          <div>
            <h2> This is Write Page </h2>
          </div>
        </div>
    );
  }
}

export default write;

