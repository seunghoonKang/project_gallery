{this.state.login 
    ? <h5> <Link to='/write'> 포스트 작성 </Link> </h5>
    : null
}
